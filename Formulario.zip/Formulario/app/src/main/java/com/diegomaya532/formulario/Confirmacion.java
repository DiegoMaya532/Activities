package com.diegomaya532.formulario;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

public class Confirmacion extends AppCompatActivity {
    private TextView tvNombre;
    private TextView tvFechaNacimiento;
    private TextView tvTelefono;
    private TextView tvCorreo;
    private TextView tvDescripcion;

    private String nombre;
    private Integer day;
    private Integer month;
    private Integer year;
    private String telefono;
    private String correo;
    private String descripcion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);

        Bundle extras = getIntent().getExtras();
        nombre = extras.getString(getResources().getString(R.string.parametroNombre));
        day = extras.getInt(getResources().getString(R.string.parametroDia));
        month = extras.getInt(getResources().getString(R.string.parametroMes));
        year = extras.getInt(getResources().getString(R.string.parametroAño));
        String fechaNacimiento = day.toString() + "/" + month.toString() + "/" + year.toString();
        telefono = extras.getString(getResources().getString(R.string.parametroTelefono));
        correo = extras.getString(getResources().getString(R.string.parametroCorreo));
        descripcion = extras.getString(getResources().getString(R.string.parametroDescripcion));

        tvNombre = (TextView)findViewById(R.id.tvNombre);
        tvFechaNacimiento = (TextView)findViewById(R.id.tvFechaNacimiento);
        tvTelefono = (TextView)findViewById(R.id.tvTelefono);
        tvCorreo = (TextView)findViewById(R.id.tvCorreo);
        tvDescripcion = (TextView)findViewById(R.id.tvDescripción);

        tvNombre.setText(nombre);
        tvFechaNacimiento.setText(fechaNacimiento);
        tvTelefono.setText(telefono);
        tvCorreo.setText(correo);
        tvDescripcion.setText(descripcion);
    }
    public void editarDatos(View view){
        Intent intent = new Intent(Confirmacion.this, MainActivity.class);
        intent.putExtra(getResources().getString(R.string.parametroNombre), nombre);
        intent.putExtra(getResources().getString(R.string.parametroDia), day);
        intent.putExtra(getResources().getString(R.string.parametroMes), month);
        intent.putExtra(getResources().getString(R.string.parametroAño), year);
        intent.putExtra(getResources().getString(R.string.parametroTelefono), telefono);
        intent.putExtra(getResources().getString(R.string.parametroCorreo), correo);
        intent.putExtra(getResources().getString(R.string.parametroDescripcion), descripcion);
        startActivity(intent);
        finish();
    }
}