package com.diegomaya532.formulario;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private TextInputEditText tietNombre;
    private DatePicker dpFecha;
    private TextInputEditText tietNumero;
    private TextInputEditText tietCorreo;
    private TextInputEditText tietDescripcion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tietNombre = (TextInputEditText)findViewById(R.id.tietNombreCompleto);
        dpFecha = (DatePicker)findViewById(R.id.dpFecha);
        tietNumero = (TextInputEditText)findViewById(R.id.tietTelefono);
        tietCorreo = (TextInputEditText)findViewById(R.id.tietCorreo);
        tietDescripcion = (TextInputEditText)findViewById(R.id.tietDescripcion);
        try{
            Bundle extras = getIntent().getExtras();
            tietNombre.setText(extras.getString(getResources().getString(R.string.parametroNombre)));
            Integer day = extras.getInt(getResources().getString(R.string.parametroDia));
            Integer month = extras.getInt(getResources().getString(R.string.parametroMes));
            Integer year = extras.getInt(getResources().getString(R.string.parametroAño));
            dpFecha.updateDate(year,month-1,day);
            tietNumero.setText(extras.getString(getResources().getString(R.string.parametroTelefono)));
            tietCorreo.setText(extras.getString(getResources().getString(R.string.parametroCorreo)));
            tietDescripcion.setText(extras.getString(getResources().getString(R.string.parametroDescripcion)));
        }catch (Exception ex){
            //Nada por ahora
        }
    }

    public void siguiente(View view){
        String nombreCompleto = tietNombre.getText().toString();
        String numeroTelefono = tietNumero.getText().toString();
        Integer day = dpFecha.getDayOfMonth();
        Integer month = dpFecha.getMonth() + 1;
        Integer year = dpFecha.getYear();
        String correoElectronico = tietCorreo.getText().toString();
        String descripcion = tietDescripcion.getText().toString();

        Intent intent = new Intent(MainActivity.this, Confirmacion.class);
        intent.putExtra(getResources().getString(R.string.parametroNombre), nombreCompleto);
        intent.putExtra(getResources().getString(R.string.parametroDia), day);
        intent.putExtra(getResources().getString(R.string.parametroMes), month);
        intent.putExtra(getResources().getString(R.string.parametroAño), year);
        intent.putExtra(getResources().getString(R.string.parametroTelefono), numeroTelefono);
        intent.putExtra(getResources().getString(R.string.parametroCorreo), correoElectronico);
        intent.putExtra(getResources().getString(R.string.parametroDescripcion), descripcion);
        startActivity(intent);
        finish();
    }
}